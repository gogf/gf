package types

type Msg struct {
	Act  string // 操作
	Data string // 数据
}
