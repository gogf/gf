package main

import "github.com/gogf/gf/g/os/glog"

func Test() {
	glog.Error("This is error!")
}

func main() {
	Test()
}
