package main

import "github.com/gogf/gf/g/os/glog"

func Test() {

}

func main() {
	glog.Line().Println("123")
}
