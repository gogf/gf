package main

import (
	"fmt"
	"github.com/gogf/gf/g/os/gfile"
)

func main() {
	fmt.Println(gfile.Basename("main.go"))
}
