package main

import (
	"fmt"
	"github.com/gogf/gf/g/util/gconv"
)

func main() {
	fmt.Println(gconv.Strings([]int{1, 2, 3}))
}
