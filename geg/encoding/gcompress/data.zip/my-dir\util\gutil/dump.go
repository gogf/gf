package main

import (
	"github.com/gogf/gf/g/util/gutil"
)

func main() {
	gutil.Dump(map[interface{}]interface{}{
		1: "john",
	})
}
